package br.com.fiap.pagamentos;

import java.util.Calendar;

public class Contrato {

	/*
	 * n�mero do contrato, data do contrato, e valor total do contrato */
	
	private int numero;
	private int dataContratoD;
	private int dataContratoM;
	private int dataContratoA;
	protected double valorTotal;
	private int qt_parcelas;
	
	public Contrato() {}

	public Contrato(int numero, int dataContratoD, int dataContratoM, int dataContratoA, double valorTotal, int qt_parcelas) {
		super();
		this.numero = numero;
		this.dataContratoD = dataContratoD;
		this.dataContratoM = dataContratoM;
		this.dataContratoA = dataContratoA;
		this.valorTotal = valorTotal;
		this.qt_parcelas = qt_parcelas;
	}
	
	/*metodos*/
	
	public void CalcGeral(double setValorTotal, int dataContratoM, int qt_parcelas) {
		double vl_total = setValorTotal;
		int data = dataContratoM; 
		int qt_parc = qt_parcelas;
		int i = 0;
		
		while(i <= qt_parc) {
			data += 1;
			i += 1;
			
			

		}
	}
	
	
	public int getQt_parcelas() {
		return qt_parcelas;
	}

	public void setQt_parcelas(int qt_parcelas) {
		this.qt_parcelas = qt_parcelas;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getDataContratoD() {
		return dataContratoD;
	}

	public void setDataContratoD(int dataContratoD) {
		this.dataContratoD = dataContratoD;
	}

	public int getDataContratoM() {
		return dataContratoM;
	}

	public void setDataContratoM(int dataContratoM) {
		this.dataContratoM = dataContratoM;
	}

	public int getDataContratoA() {
		return dataContratoA;
	}

	public void setDataContratoA(int dataContratoA) {
		this.dataContratoA = dataContratoA;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}
	

}
