package br.com.fiap.pagamentos;

import java.util.Scanner;

public class CalculosPag {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		Contrato contrato = new Contrato();
		
		System.out.println("Numero:");
		contrato.setNumero(input.nextInt());
		
		System.out.println("Digite o Dia Do Contrato:");
		contrato.setDataContratoD(input.nextInt());

		System.out.println("Digite o Mes Do Contrato:");
		contrato.setDataContratoM(input.nextInt());
		
		System.out.println("Digite o Ano Do Contrato:");
		contrato.setDataContratoA(input.nextInt());
		
		System.out.println("Valor Total:");
		contrato.setValorTotal(input.nextDouble());
		
		System.out.println("N�mero de Parcelas:");
		contrato.setValorTotal(input.nextDouble());
		
		
	}
}
